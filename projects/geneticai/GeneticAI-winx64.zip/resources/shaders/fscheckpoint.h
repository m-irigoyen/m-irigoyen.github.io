uniform sampler2D texture;
uniform float time;
uniform float lastFlashTime;
uniform bool blueTeam;

const vec3 cBlueColor = vec3(0.0, 0.0, 1.0);
const vec3 cRedColor = vec3(1.0, 0.0, 0.0);
const float cpFlashTime = 1.0;

const vec3 cWaveColor = vec3(0.1058, 0.4, 0.5686);
const vec3 cGlowColor = vec3(0.1058, 0.4, 0.5686);
const float cGlowFactor = 0.5;
//const float cOriginalAlphaCoeff = 0.25;
const float cTimeFactor = 1.0;
const float cGlowTimeFactor = 1.0;
const float cCircleWidth = 0.1;

void main()
{
	vec4 pixel = texture2D(texture, gl_TexCoord[0].xy);

	// The flash for cp check
	float checkTime = clamp(cpFlashTime - lastFlashTime, 0.0, cpFlashTime);
	vec4 flashColor = vec4(0, 0, 0, pixel.a);
	if (blueTeam)
	{
		flashColor.rgb = cBlueColor;
	}
	else
	{
		flashColor.rgb = cRedColor;
	}

	// lookup the pixel in the texture

	float glow = (cos(time * cGlowTimeFactor) + 1.0) * 0.5 * cGlowFactor;

	// Computing radius
	//float radius = cos(time * cTimeFactor);
	float radius = clamp(cos(time * cTimeFactor), -1.0, 1.0);
	//float radius = mod(cos(time * cTimeFactor), 1.0);
	//radius = clamp(radius, 0.0, 0.5);

	float dst = sqrt((gl_TexCoord[0].x - 0.5) * (gl_TexCoord[0].x - 0.5) +
		(gl_TexCoord[0].y - 0.5) * (gl_TexCoord[0].y - 0.5));

	dst = cCircleWidth - clamp(abs((cCircleWidth - dst) - radius), 0.0, cCircleWidth);
	pixel.a *= (dst / cCircleWidth) + glow;

	vec4 finalGlowColor = vec4(mix(cWaveColor, cGlowColor, glow), pixel.a);

	// multiply it by the color
	//gl_FragColor = vec4(radius, radius, radius, pixel.a);
	gl_FragColor = mix(finalGlowColor, flashColor, checkTime);
}
