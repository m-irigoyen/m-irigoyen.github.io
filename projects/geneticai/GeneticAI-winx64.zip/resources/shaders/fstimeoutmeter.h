uniform sampler2D texture;
uniform float threshold;
uniform vec4 color;

const float maxLerp = 0.95f;
const float minLerp = 0.6f;

void main()
{
	vec4 pixel = texture2D(texture, gl_TexCoord[0].xy);
	if ((pixel.a > 0.5) && (pixel.r <= threshold))
		gl_FragColor = color * mix(minLerp, maxLerp, threshold);
	else
		gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
}