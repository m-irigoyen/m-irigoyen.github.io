//uniform vec4 color;
uniform float time;
uniform float impactAngle;	// impact angle in degrees
uniform vec2 resolution;
uniform float factor;	// General factor of impact violence
uniform vec4 color;

const float waveSize = 0.25;
const float waveSpeed = 2.0;
const float minFactor = 0.3;
const float shieldRadius = 0.415;
const float PI = 3.14159265;

void main()
{
	vec2 center = vec2(0.5, 0.5);
	vec2 normalizedUV = vec2(gl_FragCoord.xy / resolution);

	if (distance(normalizedUV, center) > shieldRadius)
	{
		gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
	}
	else
	{
		float dst = distance(normalizedUV, center);
		vec2 unit = normalizedUV - center;
		unit = normalize(unit);
		unit *= shieldRadius * 2.0;

		dst *= 2.0;
		float coeff = 1.0 - sqrt(1.0 - dst * dst);

		normalizedUV = center + unit * coeff;

		vec2 unitVector = vec2(1.0, 0.0);
		unitVector *= shieldRadius;

		// Converting angle to radians
		float impactAngleRad = impactAngle * PI / 180.0;
		vec2 rotatedVector = vec2(cos(impactAngleRad) * unitVector.x - sin(impactAngleRad) * unitVector.y,
			sin(impactAngleRad) * unitVector.x + cos(impactAngleRad) * unitVector.y);
		vec2 impactPosition = vec2(0.5, 0.5) + rotatedVector;

		dst = distance(impactPosition, normalizedUV);

		dst = abs(dst - (time * waveSpeed));

		float finalWaveSize = 1.0 / waveSize;
		float intensity = 1.0 - (dst * finalWaveSize);

		gl_FragColor = vec4(color.r, color.g, color.b,
			intensity * mix(minFactor, 1.0, factor) * color.a);
	}

}