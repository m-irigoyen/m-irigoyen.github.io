uniform vec4 color;
uniform sampler2D texture;
uniform float time;
uniform int mode;
uniform vec2 resolution;

void main()
{
	vec2 normalizedUV = vec2(gl_FragCoord.xy / resolution);
	vec4 pixel = texture2D(texture, normalizedUV);
	vec4 result;

	float mask;
	if (mode == 0)
		mask = pixel.g;
	else if (mode == 1)
		mask = pixel.r;
	else
		mask = pixel.r + pixel.g;
	result = color * (mask * cos(time / 1.5));
	gl_FragColor = result;
}